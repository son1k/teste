using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DotVVM.Framework.ViewModel;

namespace OldWebApp.ViewModels
{
    public class AboutViewModel : SiteViewModel
    {
        public override string Title => "About";
    }
}

